--
-- PostgreSQL database dump
--

\restrict 0BsN1k6I8kYVlDJXn96UPPryFezAwrlufaV6t2Tpw3j8w4Wry3Ubv4FSjvk9s29

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg13+1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: bookingstatus; Type: TYPE; Schema: public; Owner: app_user
--

CREATE TYPE public.bookingstatus AS ENUM (
    'CONFIRMED',
    'PAID',
    'RESERVED',
    'AWAITING_CASH',
    'PENDING_PAYMENT',
    'CANCELLED',
    'EXPIRED',
    'NO_SHOW',
    'AWAITING_PAYMENT',
    'AWAITING_CONFIRMATION',
    'CANCELLED_BY_USER',
    'REFUNDED',
    'FAILED'
);


ALTER TYPE public.bookingstatus OWNER TO app_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO app_user;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.bookings (
    id bigint NOT NULL,
    user_id bigint,
    master_id bigint,
    service_id bigint,
    status public.bookingstatus DEFAULT 'RESERVED'::public.bookingstatus,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    original_price_cents bigint,
    final_price_cents bigint,
    cash_hold_expires_at timestamp with time zone,
    paid_at timestamp with time zone,
    payment_provider text,
    payment_id text,
    remind_24h_sent boolean DEFAULT false,
    remind_1h_sent boolean DEFAULT false,
    last_reminder_sent_at timestamp with time zone,
    last_reminder_lead_minutes integer
);


ALTER TABLE public.bookings OWNER TO app_user;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.bookings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bookings_id_seq OWNER TO app_user;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    key text,
    value text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.settings OWNER TO app_user;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO app_user;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_key_key; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_key_key UNIQUE (key);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: bookings_starts_at_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX bookings_starts_at_idx ON public.bookings USING btree (starts_at);


--
-- PostgreSQL database dump complete
--

\unrestrict 0BsN1k6I8kYVlDJXn96UPPryFezAwrlufaV6t2Tpw3j8w4Wry3Ubv4FSjvk9s29

